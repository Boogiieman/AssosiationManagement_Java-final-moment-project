package com.Bean.App;

public class Regevent {
private String id;
private String uname;
private String select;
private String date;
private String location;
private String selects;
private String uid;


public String getUid() {
	return uid;
}
public void setUid(String uid) {
	this.uid = uid;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getSelect() {
	return select;
}
public void setSelect(String select) {
	this.select = select;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getSelects() {
	return selects;
}
public void setSelects(String selects) {
	this.selects = selects;
}

}
