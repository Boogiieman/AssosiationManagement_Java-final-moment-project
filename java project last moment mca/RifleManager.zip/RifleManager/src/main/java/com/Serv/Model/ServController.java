package com.Serv.Model;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.App.*;
import com.Dao.App.Dao;

/**
 * Servlet implementation class ServController
 */
@WebServlet("/ServController")
public class ServController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String action = request.getParameter("action");
		Dao d = new Dao();
		
		if (action.equals("ulog")) {

			Register r = new Register();

			r.setEmail(request.getParameter("email"));

			r.setPword(request.getParameter("pword"));
			System.out.println("Here");

			String result = d.logUserU(r);

			if (result.equals("Success")) {
				HttpSession ses = request.getSession();
				ses.setAttribute("uemail", r.getEmail());
					request.getRequestDispatcher("userdashboard.jsp").forward(request, response);
				}
			

		}
		
		if (action.equals("log")) {

			Register r = new Register();

			r.setEmail(request.getParameter("email"));

			r.setPword(request.getParameter("pword"));
			System.out.println("Here");

			String result = d.logUser(r);

			if (result.equals("Success")) {
				if (r.getEmail().equals("admin@rifle.com")) {
					System.out.println(r.getEmail() + r.getPword());
					request.getRequestDispatcher("AdminDashboard.jsp").forward(request, response);
				} else if (r.getEmail().contains("manager")) {
					request.getRequestDispatcher("managerdashboared.jsp").forward(request, response);
				} 
			}

		}
		
		if(action.equals("regm"))
		{
			Register robj=new Register();
			robj.setUname(request.getParameter("uname"));//setting values to the bean class from jsp form fields
			robj.setEmail(request.getParameter("email"));
			robj.setLocation(request.getParameter("location"));
			robj.setPword(request.getParameter("pword"));
			
			String result=d.regUser(robj);//return comming from the dao method
	
			if(result.equals("Success"))
			{
				
				request.getRequestDispatcher("card.jsp").forward(request, response);
			}
			
		}
			if(action.equals("regu"))
			{
				User robj=new User();
				robj.setUsername(request.getParameter("username"));//setting values to the bean class from jsp form fields
				robj.setEmail(request.getParameter("email"));
				robj.setLocation(request.getParameter("location"));
				robj.setPassword(request.getParameter("password"));
				
				robj.setScheme(request.getParameter("selectScheme")); 
				
				String result=d.regUser1(robj);//return comming from the dao method
		
				if(result.equals("Success"))
				{
					
					request.getRequestDispatcher("uLogin.jsp").forward(request, response);
				}
				
			}
			if(action.equals("cr"))
			{
				Ct robj=new Ct();
				robj.setEventname(request.getParameter("eventname"));//setting values to the bean class from jsp form fields
				robj.setDate(request.getParameter("date"));
				robj.setTime(request.getParameter("time"));
				robj.setLoc(request.getParameter("location"));
			    robj.setScheme(request.getParameter("selectScheme")); 
				
				String result=d.regUser2(robj);//return comming from the dao method
		
				if(result.equals("Success"))
				{
					
					request.getRequestDispatcher("createevent.jsp").forward(request, response);
				}
				
			}
			
			if(action.equals("rege"))
			{
				System.out.println("hai");
				Regevent robj=new Regevent();
				robj.setUname(request.getParameter("uname"));//setting values to the bean class from jsp form fields
				robj.setSelect(request.getParameter("select"));
				robj.setLocation(request.getParameter("loc"));
				robj.setDate(request.getParameter("date"));
				robj.setSelects(request.getParameter("scheme"));
				
				
				String result=d.regevent(robj);//return comming from the dao method
		
				if(result.equals("Success"))
				{
					
					request.getRequestDispatcher("regforevent.jsp").forward(request, response);
				}
				
			}
			
			if(action.equals("appEvent"))
			{
				Regevent r = new Regevent();
				r.setId(request.getParameter("eid"));
				String done= d.ApproveEvent(r);
				if(done.equals("Success"))
				{
					
					request.getRequestDispatcher("adminverifyevents.jsp").forward(request, response);
				}
			}
			
			if(action.equals("book"))
			{
				Regevent r = new Regevent();
				r.setId(request.getParameter("eid"));
				System.out.println(request.getParameter("eid"));
				r.setUid(request.getParameter("uid"));
				
				String done= d.bookEvent(r);
			
				System.out.println(done+" Done Value");
				if(done.equals("Success"))
				{
					System.out.println(request.getParameter("uid")+"in Serv	");
					request.getRequestDispatcher("userdashboard.jsp").forward(request, response);
				}
			}
			if(action.equals("win"))
			{
				Regevent r = new Regevent();
				r.setId(request.getParameter("eid"));
				System.out.println(request.getParameter("eid"));
				r.setUid(request.getParameter("uid"));
				
				String done= d.winEvent(r);
			
				System.out.println(done+" Done Value");
				if(done.equals("Success"))
				{
					System.out.println(request.getParameter("uid")+"in Serv	");
					request.getRequestDispatcher("managerdashboared.jsp").forward(request, response);
				}
			}
	}

}
