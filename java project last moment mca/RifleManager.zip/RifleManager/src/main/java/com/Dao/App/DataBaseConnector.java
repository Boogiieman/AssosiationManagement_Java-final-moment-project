package com.Dao.App;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataBaseConnector {

	public Connection connect;
	
	public Connection Dbconnect()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch (ClassNotFoundException e) {
			System.out.println(e);
		}
		try
		{
			connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/prj","root","");
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return connect;
	}
	
	
}
