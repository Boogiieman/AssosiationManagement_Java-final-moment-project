package com.Dao.App;

import java.sql.*;

import com.Bean.App.Ct;
import com.Bean.App.Regevent;
import com.Bean.App.Register;
import com.Bean.App.User;

public class Dao {

	Connection con = null;
	Statement st = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	DataBaseConnector dobj = new DataBaseConnector();
	String query = null;

	// Insrt

	public String regUser(Register robj) {
		try {
			query = "insert into regm (uname,pword,email,loc) values(?,?,?,?)";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			ps.setString(1, robj.getUname());// giving parameter values to the query
			ps.setString(2, robj.getPword());
			ps.setString(3, robj.getEmail());
			ps.setString(4, robj.getLocation());

			int i = ps.executeUpdate();// collecting the execution status

			if (i != 0)// checking whether the action is successfully completed or not success==1 if
						// not it is 0
			{
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";

	}

	public String regUser1(User robj) {
		try {
			query = "insert into regu(uname,pword,email,loc,scheme) values(?,?,?,?,?)";
			
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			
			ps.setString(1, robj.getUsername());// giving parameter values to the query
			ps.setString(2, robj.getPassword());
			ps.setString(3, robj.getEmail());
			ps.setString(4, robj.getLocation());
			ps.setString(5, robj.getScheme());

			
			int i = ps.executeUpdate();// collecting the execution status
			
			if (i != 0)// checking whether the action is successfully completed or not success==1 if
						// not it is 0
			{
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";

	}

	public String regUser2(Ct robj) {
		try {
			query = "insert into createvent(ename, time, date, loc, scheme) values(?,?,?,?,?)";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			ps.setString(1, robj.getEventname());// giving parameter values to the query
			ps.setString(2, robj.getTime());
			ps.setString(3, robj.getDate());
			ps.setString(4, robj.getLoc());
			ps.setString(5, robj.getScheme());

			int i = ps.executeUpdate();// collecting the execution status

			if (i != 0)// checking whether the action is successfully completed or not success==1 if
						// not it is 0
			{
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";

	}

	public String regevent(Regevent robj) {
		try {
			query = "insert into regevent (uname,selecte,date,loc,scheme,winner) values(?,?,?,?,?,?)";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			ps.setString(1, robj.getUname());// giving parameter values to the query
			ps.setString(2, robj.getSelect());
			ps.setString(3, robj.getDate());
			ps.setString(4, robj.getLocation());
			ps.setString(5, robj.getSelects());
			ps.setString(6, "0");

			int i = ps.executeUpdate();// collecting the execution status

			if (i != 0)// checking whether the action is successfully completed or not success==1 if
						// not it is 0
			{
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";

	}

	public String logUser(Register r) {

		try {

			String q = "select * from regm";
			con = dobj.Dbconnect();
			st = con.createStatement();

			rs = st.executeQuery(q);

			while (rs.next()) {

				if (rs.getString("email").equals(r.getEmail()) && rs.getString("pword").equals(r.getPword())) {

					return "Success";

				}

			}

		} catch (Exception e) {

			System.out.println();

		}

		return "";

	}
	
	public String logUserU(Register r) {

		try {

			String q = "select * from regu";
			con = dobj.Dbconnect();
			st = con.createStatement();

			rs = st.executeQuery(q);

			while (rs.next()) {

				if (rs.getString("email").equals(r.getEmail()) && rs.getString("pword").equals(r.getPword())) {

					return "Success";

				}

			}

		} catch (Exception e) {

			System.out.println();

		}

		return "";

	}

	public String ApproveEvent(Regevent r) {
		
		try {
			query = "update createvent set status=1 where id='"+r.getId()+"'";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			

			int i = ps.executeUpdate();// collecting the execution status

			if (i != 0)// checking whether the action is successfully completed or not success==1 if
						// not it is 0
			{
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";
	}

	public String bookEvent(Regevent r) {
		try {
			System.out.println(r.getId()+"  In Dao");
			
			query = "update regu set eid=? where uid='"+r.getUid()+"'";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			ps.setString(1, r.getId());
			int i=ps.executeUpdate();
			System.out.println(i+" i Value");
			if (i != 0)
			{
				
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";
	}

	public String winEvent(Regevent r) {
		try {
			System.out.println(r.getId()+"  In Dao");
			
			query = "update createvent set winner=? where id='"+r.getId()+"'";
			con = dobj.Dbconnect();
			ps = con.prepareStatement(query);
			ps.setString(1, r.getUid());
			int i=ps.executeUpdate();
			System.out.println(i+" i Value");
			if (i != 0)
			{
				
				return "Success";
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return "";
	}
}
